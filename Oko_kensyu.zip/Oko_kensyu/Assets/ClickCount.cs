﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ClickCount : MonoBehaviour
{
    private int clickTimes; //クリックした回数
    public Text clickText;　//クリックした回数を表示するテキスト
    public Text clickTextCumu; //累計クリック数を表示するテキスト
    public Text goal; //次の目標を表示するテキスト
    public Text high; //ハイスコアの表示をするテキスト
    private Count script;　//カウントダウンのスクリプト
    public int clcumu = 0; //クリックした回数
    public int goalcount = 10; //次の目標
    public int highscoreBe; //最高記録
    public int score; //現在の記録

    void Start()
    {
        script = GetComponent<Count>();

        clickText.text = "クリック数:" + clickTimes.ToString("d");

        clcumu = PlayerPrefs.GetInt("CliCumu");
        clickTextCumu.text = "累計クリック数" + clcumu.ToString("d");

        goal.text = "次の目標" + goalcount.ToString("d");

        highscoreBe = PlayerPrefs.GetInt("HighScore");
        high.text = "最高記録" + highscoreBe.ToString("d");
        Debug.Log(highscoreBe);
    }

    private void OnDestroy()
    {
        PlayerPrefs.SetInt("CliCumu", clcumu);
        PlayerPrefs.Save();
    }

    public void ResetM()
    {
        PlayerPrefs.SetInt("Clicumu", 0);
        clcumu = 0;

        PlayerPrefs.SetInt("HighScore", 0);

        SceneManager.LoadScene("Start");

    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && script.limitTime > 0)
        {
            clickTimes += 1;
            clickText.text = "クリック数:" + clickTimes.ToString("d");

            clcumu += 1;
            clickTextCumu.text = "累計クリック数" + clcumu.ToString("d");
        }
        else if (script.limitTime < 0)
        {
            score = clickTimes;

            if (score > highscoreBe)
            {
                highscoreBe = score;
                high.text = "最高記録" + highscoreBe.ToString("d");
                PlayerPrefs.SetInt("HighScore", highscoreBe);
            }
        }

        if (clcumu >= goalcount)
        {
            goalcount *= 10;
            goal.text = "次の目標" + goalcount.ToString("d");
        }


    }
}

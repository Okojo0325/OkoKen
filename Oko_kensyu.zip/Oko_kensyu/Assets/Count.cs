﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Count : MonoBehaviour
{
    public float limitTime = 10f;
    public Text timeText;

    // Update is called once per frame
    void Update()
    {
        limitTime -= Time.deltaTime;
        timeText.text = "カウントダウン:" + limitTime.ToString("f0");
        if (limitTime < 0)
        {
            timeText.text = "終了";
        }
    }
}
